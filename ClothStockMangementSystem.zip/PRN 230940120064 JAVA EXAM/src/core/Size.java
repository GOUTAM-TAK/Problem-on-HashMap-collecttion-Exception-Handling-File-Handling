package core;

public enum Size {
       S,M,L,XL,XLL;
}
