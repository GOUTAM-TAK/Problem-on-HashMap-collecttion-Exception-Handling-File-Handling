package core;

public enum Category {
    MENS_TSHRT,MENS_SHIRT,WOMENS_JEANS,WOMENS_SARI;
}
