package exception;

@SuppressWarnings("serial")
public class ClothException extends Exception {

	

	public ClothException(String message) {
		super(message);
	
	}

	

}
